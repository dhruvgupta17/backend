// init project
var express = require("express");
var bodyParser = require("body-parser");
var app = express();
const mongoose = require('mongoose');
var url = String(process.env.HOSTNAME).split("-");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));



// This route processes GET requests to "/"`
app.get("/", function(req, res) {
  res.send(
    '<h1>REST API</h1><p>A REST API starter using Express and body-parser.<br /><br />To test, curl the following and view the terminal logs:<br /><br /><i>curl -H "Content-Type: application/json" -X POST -d \'{"username":"test","data":"1234"}\' https://' +
      url[2] +
      ".sse.codesandbox.io/update<i></p>"
  );
  console.log("Received GET");
});


// A GET request handler for `/update`
// app.get("/update", function(req, res) {
//   var dummyData = {
//     username: "testUser",
//     data: "1234"
//   };
//   console.log("Received GET: " + JSON.stringify(req.body));
//   if (!req.query.username) {
//     return res.send({ status: "error", message: "no username" });
//   } else if (!req.query.data) {
//     return res.send({ status: "error", message: "no data" });
//   } else if (req.query.username != dummyData.username) {
//     return res.send({ status: "error", message: "username does not match" });
//   } else {
//     return res.send(dummyData);
//   }
// });



// A route for get requests sent to `/get by id`
app.get('/update:postId', async(req, res)=> {
  try{
      const savedata = await sendTomogo.findById(req.params.postId)
      res.json({savedata, status:"success",})
  }catch(err){
      res.json({message:err,status:"error"})
  }
});




// A route for get requests sent to `/get all`
app.get("/update", async(req, res)=> {
    try{
        const savedata = await sendTomogo.find()
        return  res.json({savedata, status:true,})
    }catch(err){
      return res.json({message:err,status:false,})
    }
});


// A route for POST requests sent to `/create object`
app.post("/update", async(req, res)=> {
  if (!req.body.firstname || !req.body.lastname || !req.body.age) {
    console.log("please insert all the details")
    return res.status(400).json({ status: "error", message: "please insert all the details" });
  } else {
    try{
      const post = new sendTomogo(req.body);
        const savedata = await post.save()
        res.json({savedata, status:true, message: "details inseted successfully",})
        console.log("details inseted successfully");
    }catch(err){
        res.json({message:err })
    }
  }
});

// A route for POST requests sent to `/delete by id`
app.delete('/update:postId', async(req, res)=> {
  try{
      const savedata = await sendTomogo.remove({_id:req.params.postId})
      res.json({savedata, status:true, message:"delete successfully",})
  }catch(err){
      res.json({message:err,status:"error"})
  }
});


// A route for POST requests sent to `/edit by id`
app.patch('/update:postId', async(req, res)=> {
  try{
      const savedata = await sendTomogo.update({_id:req.params.postId},{$set:{
        firstname:req.body.firstname,
        lastname:req.body.lastname,
        age:req.body.age
      }})
      res.json({savedata, status:"update successfully",})
  }catch(err){
      res.json({message:err,status:"error"})
  }
});







app.post("/register", async(req, res)=> {
  if (!req.body.username || !req.body.email || !req.body.password) {
    console.log("please insert all the details")
    return res.status(400).json({ status: "error", message: "please insert all the details" });
  } else {
    try{
      const post = new sendUserDetails(req.body);
        const savedata = await post.save()
        res.json({savedata, status:true, message: "details inseted successfully",})
        console.log("details inseted successfully");
    }catch(err){
        res.json({message:err })
    }
  }
});




app.post("/login", async(req, res)=> {
  try{
    const getloginuser = await sendUserDetails.findOne({email:req.body.email})
    if(getloginuser){
      if(getloginuser.password===req.body.password){
        let response={
          data:{
          username:getloginuser.username,
          email:getloginuser.email
        },
          status:true,}
        return  res.send(response)
      }else{
        return  res.json({message:"password not currect", status:false,})
      }
    }else{
      return  res.json({message:"email not currect", status:false,})
    }
  }catch(err){
    return res.status(400).send({msg:"unsuccessful"})
  }
});



const PostSchema = new mongoose.Schema({
  firstname:{
    type:String,
    required:true
  },
  lastname:{
    type:String,
    required:true
  },
  age:{
    type:Number,
    required:true
  }
});

const UserSchema = new mongoose.Schema({
  username:{
    type:String,
    required:true
  },
  email:{
    type:String,
    required:true
  },
  password:{
    type:String,
    required:true
  }
});


const sendTomogo = mongoose.model('ServiceData', PostSchema);
const sendUserDetails = mongoose.model('UserData', UserSchema);

mongoose.connect('mongodb+srv://DHRUV:dhruv12345@cluster0.hae3y.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',{
  useNewUrlParser: true,
  useUnifiedTopology: true,  }
).then(() => console.log("Database connected!"))
.catch(err => console.log(err));



// Listen on port 8080
var listener = app.listen(8080, function() {
  console.log("Listening on port " + listener.address().port);
});
